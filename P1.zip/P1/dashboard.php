<?php
    date_default_timezone_set('America/Mazatlan');

    // require('header.php');
    require('conexion/db.php');
    require('inc/consultar.inc.php');
    
    $result;
    $resultI;
    $resultS;
    $resultID;
    $diaActual;

    $today = getdate();
    $diaActual = array('año' => $today['year'], 'mes' => $today['mon'], 'dia' => $today['mday']);
    $sesion = $_GET['login'];
    $sesionId = $_GET['id'];

    if(isset($_GET['periodo'])) {
        $periodo = $_GET['periodo'];     
        if(empty($periodo)) {
            // $diaActual = array('año' => $today['year'], 'mes' => $today['mon'], 'dia' => $today['mday']);
            $periodo = $diaActual['año'] . '-' . $diaActual['mes'] . '-' . $diaActual['dia'];    
        }  
    } 
    else {
        $periodo = $today['year'] . '-' . $today['mon'] . '-'  . $today['mday'];
        // $diaActual = array('año' => $today['year'], 'mes' => $today['mon'], 'dia' => $today['mday']);
    }



    if(empty($sesionId)){
        header('location:index.php');
        session_destroy();
    } else {
        $query = 'select user,id from usuarios where id = ? ';

        $qprepare = $bd_conection->prepare($query);
        $qprepare->execute(array($sesionId));

        $resultID = $qprepare->fetch(PDO::FETCH_ASSOC);

        if($resultID['id']){
            // $queryI = 'select deuda,costo from deduas where id_usuarios = ?';
            // $qprepareI = $bd_conection->prepare($queryI);
            // $qprepareI->execute(array($resultID['id']));

            // $resultI = $qprepareI->fetchAll(PDO::FETCH_ASSOC);
           
            
            $queryS = "SELECT saldo,date_format(inicio_periodo,'%e-%m-%Y') as inicio_periodo FROM saldos where id_user = ? order by id desc limit 1";
            $qprepareS = $bd_conection->prepare($queryS);
            $qprepareS->execute(array($resultID['id']));

            $resultS = $qprepareS->fetch(PDO::FETCH_ASSOC);
            // print_r($resultI);
            
               
        }
    }      
    
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="fontawesome-free-5.15.1-web\css\all.css">
    <title>Document</title>
</head>
<body>
    <header>        
    </header>
    <main>

        <div class="contenedor-ds">
            <div class="ds-titulo" >
                <div class="logo">
                    <h1 class="titulo" >SAfiRO </h1>  
                    <i class="fas fa-wallet wallet"></i>
                </div>
                
                <form action="inc/logout.inc.php" method="post">
                    <input type="submit" value="Cerrar sesión">
                </form>
            </div>
            
            <div class="header-card">

                <div class="header-ds">

                    <div class="user" >
                        <i class="fas fa-hand-holding-usd money"></i>
                        <!-- <i class="fas fa-money-bill-wave money" ></i> -->
                        <div>
                            <?php
                                echo '<p> Hola <span>' . ucwords($sesion) . '</span></p>';                
                            ?>
                        </div>
                        <div>
                            <?php
                            
                                echo '<p>saldo del periodo: ' . $resultS['inicio_periodo'] .  '</p>';
                                echo '<p> $ <span>' . $resultS['saldo'] . '</span> </p>';
                            ?>
                        </div>
                    </div>
                </div> <!-- header-ds -->

                <section class="valores">

                    <form action="inc/registrar.inc.php" method="post" class="saldo">
                        <input type="hidden" name="id" value = <?php echo $resultID['id']   ?>>
                        <input type="hidden" name="sesion" value = <?php echo $sesion   ?>>
                        <input type="text" name="saldo" id="saldo" placeholder="saldo" required>
                        <input type="submit" class="btn-secundario" value="Agregar">

                    </form>

                    <form action="inc/registrar.inc.php" method="post" class="deudas">

                        <input type="hidden" name="id" value = <?php echo $resultID['id']   ?>>
                        <input type="hidden" name="sesion" value = <?php echo $sesion   ?>>
                        <input type="text" name="cuenta" id="cuenta" placeholder="cuenta" required>
                        <input type="number" name="deuda" id="deuda" placeholder="deuda" required>
                        
                        <input type="submit" class="btn-secundario" value="Agregar">

                    </form>
                    <form action="dashboard.php" method="get">    
                        <input type="hidden" name="id" value = <?php echo $resultID['id']   ?>>      
                        <input type="hidden" name="login" value = <?php echo $sesion   ?>>          
                        <input type="date" name="periodo" id="periodo">
                        <input type="submit" class="btn-secundario" id="consulta" value="Consultar">
                    </form>

                </section>

                
            </div> <!--  header-card-->
            

            <section class="gestor">   
                <?php

                    echo '<h1>' . $diaActual['dia'] . '-' . $diaActual['mes'] . '-' . $diaActual['año'] . '</h1>';                        
                    
                ?>

                <div class="t-deuda">
                    <h2>Cuentas</h2>
                    <h2>Deuda</h2>
                    <h2>Día</h2>
                    <h2>Pagado</h2>
                </div>    

                <?php
                     if($periodo == ''){
                        // $periodo = $diaActual['dia'] . '-' . $diaActual['mes'] . '-' . $diaActual['año'];
                        $resultI = consultarDeudas($resultID['id'],$periodo);
                        echo '<p> Selecciona una fecha para consultar tus deudas </p>';
                    } 
                    else {
                        // $periodo = array('año' => $today['year'], 'mes' => $today['mon'], 'dia' => $today['mday']);
                        // $periodo =  $periodo['año'] .'-'. $periodo['mes'] .'-'. $periodo['dia'];   
                        $resultI = consultarDeudas($resultID['id'],$periodo);                       
                        
                    }
                    if(count($resultI) > 0){
                        $contador = 0;
                        // print_r($resultI);
                        echo '<form action="inc/registrar.inc.php" method="post" class="grid">';
                            foreach($resultI as $items => $item){
                                
                                echo '<div class="deuda">';                
                                    echo '<p class="d-i">' . ucwords($item['deuda']) . '</p>';  
                                    echo '<p class="d-i">' . $item['costo'] . '</p>';   
                                    echo '<p class="d-i">' . $item['fecha_registro'] . '</p>';   
                                    echo '<div class="d-i"> 
                                            <div class="marca ' ; if($item['pagado'] == 1) echo 'marcado disabled'; echo '"> 
                                                <input type="hidden" name="marcaid[]" id="marcaid" value= "' . $item['id'].'" >
                                                <input type="hidden" name="marca[]" id="marca" value="';
                                                if($item['pagado'] == 1) { 
                                                    echo '1';
                                                } else { 
                                                    echo '0';}
                                                echo '">
                                            </div> 
                                         </div>';
                                    // echo '</p>';
                                echo '</div>';

                            }
                            echo '<input type="hidden" name="id" value = "' . $resultID['id'] . '">';      
                            echo '<input type="hidden" name="sesion" value = " ' . $sesion .'">';
                            echo '<input type="hidden" name="periodo" value = " ' . $periodo .'">';
                            
                            echo '<input type="submit" value="Guardar cambios" class="">';
                        echo '</form>';
                    } else {
                        echo '<p class="error"> Sin deudas Registradas </p>';
                    }
                ?>
                <!-- <div class="deuda">
                    <p>Renta</p>
                    <p>1000</p>
                </div>
                <div class="deuda">
                    <p>Renta</p>
                    <p>1000</p>
                </div>
                <div class="deuda">
                    <p>Renta</p>
                    <p>1000</p>
                </div>
                <div class="deuda">
                    <p>Renta</p>
                    <p>1000</p>
                </div>
                <div class="deuda">
                    <p>Renta</p>
                    <p>1000</p>
                </div> -->

            
            </section>
                
        </div>

    </main>
    <?php 
        include('footer.php');
    ?>

    <script src="js/index.js"></script>
</body>


</html>

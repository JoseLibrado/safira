<?php
    $alert = '';      
    if(isset($_REQUEST['registro']))    {$registro = $_REQUEST['registro'];} else {$registro = '';};

    if($registro == 'exitoso'){
        $alert = '<p class="exito"> Gracias por registrarte. Ya puedes iniciar sesión.</p>';
    }
    if($registro == 'existente'){
        $alert = '<p class="error"> Este Usuario ya cuenta con una cuenta registrada.</p>';
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="fontawesome-free-5.15.1-web\css\all.css">
    <title>Document</title>
</head>
<body>
    <div class="contenedor-index"> 
        <div class="contenedor-ds">
            <div class="ds-titulo" >
                <div class="logo">
                    <h1 class="titulo" >SAfiRO </h1>  
                    <i class="fas fa-wallet wallet"></i>
                </div>   
                <p>Sistema Administrador Financiero</p>      
            </div>
            <div class="header-card-ind">
                <i class="fas fa-hand-holding-usd money"></i>
                <form class="login-fields" action="inc/registrar.inc.php" method='post'>
                    <input type="text" name='user' placeholder='Nombre/Usuario' required>
                    <input type="text" name="telefono" id="telefono" placeholder='Teléfono' required>
                    <input type="password" name="psw-conf" id="psw-conf" placeholder='Contraseña' required>
                    <input type="submit" class="btn-primario" value="Registrate">
                </form>   
                <?php
                    isset($alert) ? $alert : '';
                    echo $alert;
                ?>
                <p>Este sistema te puede ayudar en tener un orden haciendo una lista de deudas que necesitas pagar.
                    Solo requiere que ingreses un monto, captures las deudas para tener enlistadas y llevar el control.</p>             
                
            </div>
            <a href="index.php" class="enlaces ">Iniciar Sesión</a>
        </div>
    </div>   
    <?php 
        include('footer.php');
    ?> 
</body>
</html>


(() => {

    'use strict';


const validaCheck = elemento => {     
    if(document.querySelectorAll(elemento)){
        return document.querySelectorAll(elemento);
    }
}

const check = validaCheck('.marca');
const marca = validaCheck('#marca');

check.forEach( item => {
    item.addEventListener('click', () => {
        
        if(item.className.includes('marcado')) {
            item.classList.remove('marcado');

            for(let i = 0; i < check.length ; i++){
                if(!(check[i].className.includes('marcado'))){
                    marca[i].setAttribute('value','0');
                }
            }

        } else {
            item.classList.add('marcado');
        }

        for(let i = 0; i < check.length ; i++){
            if(check[i].className.includes('marcado') || check[i].className.includes('disabled')){
                marca[i].setAttribute('value','1');
            }
        }    
    });
});


// for(let i = 0; i < check.length ; i++ ) {
//     if(check[i].className.includes('disabled')){
//         marca[i].setAttribute('value','1');
//     } 
// }
} )();
<?php
    // variables

    $cuenta;
    $deuda;
    $id;
    $sesion;
    $usuario;
    $telefono;
    $conftelefono;
    
    if(isset($_REQUEST['user']))        $usuario           = $_REQUEST['user'];
    if(isset($_REQUEST['telefono']))    $telefono          = $_REQUEST['telefono'];
    if(isset($_REQUEST['psw-conf']))    $contraseña        = $_REQUEST['psw-conf'];

    if(isset($_REQUEST['cuenta']))      $cuenta            = $_REQUEST['cuenta'];
    if(isset($_REQUEST['deuda']))       $deuda             = $_REQUEST['deuda'];
    if(isset($_REQUEST['id']))          $id                = $_REQUEST['id'];
    if(isset($_REQUEST['sesion']))      $sesion            = $_REQUEST['sesion'];
    if(isset($_REQUEST['periodo']))     $periodo           = $_REQUEST['periodo'];

    if(isset($_REQUEST['saldo']))       $saldo             = $_REQUEST['saldo'] ;

    // update lista del grid
    if(isset($_REQUEST['marcaid']))     $ArrmarcaId        = $_REQUEST['marcaid'] ;
    if(isset($_REQUEST['marca']))       $Arrmarca          = $_REQUEST['marca'] ;

    // print_r($marcaId);
    // print_r($marca);

    // funciones
    function actualizaStatusDeuda($arregloId,$arregloStatus,$Iid,$Isesion,$Iperiodo){

        require('../conexion/db.php');
        
        // $arregloDeudas = new array();
        $centinela = 0;

        for($i = 0; $i < count($arregloId) ; $i++){

            $qActualiza = 'call sp_actualiza_estatus_deuda(?,?)';
            // update deduas set pagado = ? where id = ?';

            $qprepare = $bd_conection->prepare($qActualiza);
            
            $qprepare->execute(array($arregloStatus[$i],$arregloId[$i]));

            $centinela = $i;    
        }
            header('location:../dashboard.php?actualizado=ok&login=' . $Isesion .'&id=' . $Iid . '&periodo='. $Iperiodo);
    }

    function registraDeuda($Icuenta,$Ideuda,$Iid,$Isesion){
        require('../conexion/db.php');

        $qDeuda = 'call sp_inserta_deuda(?,?,?)'; 
        $qprepare = $bd_conection->prepare($qDeuda);

        if($qprepare->execute(array($Icuenta,$Ideuda,$Iid))){
            header('location:../dashboard.php?registro=ok&login=' . $Isesion .'&id=' . $Iid);
        } else {
            echo 'bad request';
        }
    }

    function registraSaldo($Isaldo,$Iid,$Isesion) {
        require('../conexion/db.php');

        $qSaldo = 'call sp_inserta_saldo(?,?)';

        $qprepareS = $bd_conection->prepare($qSaldo);

        if($qprepareS->execute(array($Isaldo,$Iid))){
            header('location:../dashboard.php?registro=ok&login=' . $Isesion .'&id=' . $Iid );
        }else {
            echo 'bad request';
        }
    }

    function registrarUsuario($Inombre,$Itelefono,$Icontraseña){

        require('../conexion/db.php');

        $qValida = "call sp_valida_usuario_existente(?,?)";
        // $qValida = "SELECT telefono FROM usuarios WHERE telefono = ? AND user = ?";

        $qValidaP = $bd_conection->prepare($qValida);

        $qValidaP->execute(array($Itelefono,$Inombre));
        
        $row = $qValidaP->fetch(PDO::FETCH_ASSOC);
        
        
        if($row = $qValidaP->fetch(PDO::FETCH_ASSOC)){            
            header('location:../registrar.php?registro=existente');
            // echo'hola';
        } else {            
            $bd_conection=null;
            require('../conexion/db.php');
            $hash = password_hash($Icontraseña,PASSWORD_DEFAULT);

            $qregistro = 'call sp_registra_usuarios(?,?,?)';
    
            $qprepareR = $bd_conection->prepare($qregistro);
    
            if($qprepareR->execute(array($Inombre,$Itelefono,$hash))){
                header('location:../registrar.php?registro=exitoso');

                // header('location:../dashboard.php?registro=ok&login=' . $Isesion);
            }else {
                echo 'bad request';
                print_r($qprepareR->errorInfo());

            }
        }

       
    }

    // ===========  llamado de funciones
    
    if(isset($deuda)){
        registraDeuda($cuenta,$deuda,$id,$sesion);
    }
    if (isset($saldo)) {
        registraSaldo($saldo,$id,$sesion);
    }
    if(isset($usuario)) {
        registrarUsuario($usuario,$telefono,$contraseña);
    }
    if(isset($ArrmarcaId)) {
        actualizaStatusDeuda($ArrmarcaId,$Arrmarca,$id,$sesion,$periodo);
    }

    $bd_conection=null;

    //functiones fin 
?>
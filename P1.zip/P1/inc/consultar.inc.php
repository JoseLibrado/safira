<?php
    
    function consultarDeudas($Iid,$Iperiodo) {        

            
            require('conexion/db.php');

            $qDeudas = 'call sp_periodo_deudas(?,?)';
    
            $qprepapre = $bd_conection->prepare($qDeudas);
    
            $qprepapre->execute(array($Iid,$Iperiodo));

            $data = $qprepapre->fetchAll(PDO::FETCH_ASSOC);
            
            return $data;

    }
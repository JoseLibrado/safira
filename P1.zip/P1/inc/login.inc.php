<?php
    require('../conexion/db.php');
    
    $usuario = $_REQUEST['user'];
    $telefono   = $_REQUEST['telefono'];
    $contraseña   = $_REQUEST['psw-conf'];
    
    $query = "call sp_login_usuarios(?,?)";
    $qprepare = $bd_conection->prepare($query);

    $qprepare->execute(array($usuario,$telefono,));
    
    if($result = $qprepare->fetch(PDO::FETCH_ASSOC)){
        password_verify($contraseña,$result['sha_pass']);
        session_start();
        $_SESSION['login'] = $result['user'];
        $_SESSION['id']    = $result['id'];
        header('location:../dashboard.php?login=' . $_SESSION['login'] .'&id='. $_SESSION['id'] );
    } else {
        header('location:../index.php?field=failed');
    }

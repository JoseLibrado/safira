<?php
    $alert = '';      
    $field = isset($_GET['field']);

    if($field == 'failed'){
        $alert = '<p class="error"> Ingrese los datos correctos para iniciar sesión </p>';
    } else if($field == 'invalid'){
        echo 'Login Invalid';
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="fontawesome-free-5.15.1-web\css\all.css">
    <title>Document</title>
</head>
<body>
    <div class="contenedor-index"> 
        <div class="contenedor-ds">
            <div class="ds-titulo" >
                <div class="logo">
                    <h1 class="titulo" >SAfiRO </h1>  
                    <i class="fas fa-wallet wallet"></i>
                </div>   
                <p>Sistema Administrador Financiero</p>      
            </div>
            <div class="header-card-ind">
                <i class="fas fa-hand-holding-usd money"></i>
                <form class="login-fields" action="inc/login.inc.php" method='post'>
                    <input type="text" name='user' placeholder='Nombre/Usuario' required>
                    <input type="text" name="telefono" id="telefono" placeholder='Teléfono' required>
                    <input type="password" name="psw-conf" id="psw-conf" placeholder='Contraseña' required>
                    <input type="submit" class="btn-primario" value="Iniciar sesión">
                </form>   
                <?php
                    isset($alert) ? $alert : '';
                    echo $alert;
                ?>
                
                <a href="registrar.php" class="enlaces">Registrate</a>
                <p>Este sistema te puede ayudar en tener un orden haciendo una lista de deudas que necesitas pagar.
                    Solo requiere que ingreses un monto, captures las deudas para tener enlistadas y llevar el control.</p>             
                
            </div>
            <!-- <a href="registrar.php" class="enlaces">Registrate ...</a> -->
        </div>
    </div> 
    <?php 
        include('footer.php');
    ?>
</body>
</html>
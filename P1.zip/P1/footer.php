

<footer class="ftr">  
    <div>
    <p>Version de desarrollado V1.0 07-01-2021</p>
    <p>José Librado Soto Obeso joselibrado.sotoobeso@gmail.com</p>
    </div>

</footer>